#!/bin/bash
set -e

env_cmakelists="$(dirname $(readlink -f "$0"))/../minizero/environment/CMakeLists.txt"
support_games=($(awk '/target_include_directories/,/\)/' ${env_cmakelists} | sed 's|/|\n|g' | grep -v -E 'target|environment|PUBLIC|CMAKE_CURRENT_SOURCE_DIR|base|stochastic|)'))

usage()
{
echo "Usage: $0 GAME_TYPE CONFIGURE_FILE END_ITERATION [OPTION]..."
echo "The zero-server manages the training session and organizes connected zero-workers."
echo ""
echo "Required arguments:"
    echo "  GAME_TYPE: ${support_games[@]}"
echo "  CONFIGURE_FILE: the configure file (*.cfg) to use"
echo "  END_ITERATION: the total number of iterations for training"
echo ""
echo "Optional arguments:"
echo "  -h,        --help                 Give this help list"
echo "  -n,        --name                 Assign name for training directory"
echo "  -np,       --name_prefix          Add prefix name for default training directory name"
echo "  -ns,       --name_suffix          Add suffix name for default training directory name"
echo "  -g,        --gpu                  Assign the GPU for network model initialization, e.g. 0"
echo "             --sp_executable_file   Assign the path for self-play executable file"
echo "             --op_executable_file   Assign the path for optimization executable file"
echo "             --link_sgf             Assign the path of sgf for training without self play (only op)"
echo "  -conf_str                         Overwrite settings in the configure file"
exit 1
}

# check argument
if [ $# -lt 3 ] || [ $(($# % 2)) -eq 0 ]; then
usage
else
game_type=$1; shift
configure_file=$1; shift
end_iteration=$1; shift
fi

train_dir=""
name_prefix=""
name_suffix=""
gpu_list=$(nvidia-smi --query-gpu=index,memory.used,utilization.gpu --format=csv,noheader,nounits | sort -k2n -k3n | head -1 | cut -d, -f1)
sp_executable_file=build/${game_type}/minizero_${game_type}
op_executable_file=minizero/learner/train.py
overwrite_conf_str=""
link_sgf=""

while :; do
case $1 in
-h|--help) shift; usage
;;
-n|--name) shift; train_dir=$1
;;
-np|--name_prefix) shift; name_prefix=$1
;;
-ns|--name_suffix) shift; name_suffix=$1
;;
-g|--gpu) shift; gpu_list=$1
;;
--sp_executable_file) shift; sp_executable_file=$1
;;
--op_executable_file) shift; op_executable_file=$1
;;
--link_sgf) shift; link_sgf=$1
;;
-conf_str) shift; overwrite_conf_str=$1
;;
"") break
;;
*) echo "Unknown argument: $1"; usage
;;
esac
shift
done

append_cornpuzzle_cfg()
{
local target_cfg=$1
local source_cfg=$2

if [ "${game_type}" = "cornpuzzle" ]; then
for key in env_compound_piece_library env_compound_puzzles_dir env_compound_random_select_puzzle; do
if ! grep -q "^${key}=" "${target_cfg}"; then
line=$(grep "^${key}=" "${source_cfg}" | tail -n 1 || true)
if [ ! -z "${line}" ]; then
echo "${line}" >> "${target_cfg}"
fi
fi
done
fi
}

# create default name; also check if configurations are valid
testrun_stderr_tmp=$(mktemp)
default_name=$(${sp_executable_file} -mode zero_training_name -conf_file ${configure_file} -conf_str "${overwrite_conf_str}" 2>${testrun_stderr_tmp} || :)
testrun_stderr=$(<${testrun_stderr_tmp})
rm -f ${testrun_stderr_tmp}

if [[ ! ${default_name} ]]; then
echo "${testrun_stderr}" >&2
exit 1
fi

# use default name of training if name is not assigned
if [[ -z ${train_dir} ]]; then
train_dir=${name_prefix}${default_name}${name_suffix}
fi

run_stage="R"
if [ -d ${train_dir} ]; then
if [[ -n ${MINIZERO_RUN_STAGE:-} ]]; then
run_stage=${MINIZERO_RUN_STAGE}
echo "${train_dir} has existed. Automatic choice: ${run_stage}"
else
read -n1 -p "${train_dir} has existed. (R)estart / (C)ontinue / (Q)uit? " run_stage
echo ""
fi
fi

zero_start_iteration=1
model_file="weight_iter_0.pt"

if [[ ${run_stage,} == "r" ]]; then
rm -rf ${train_dir}

echo "create ${train_dir} ..."
mkdir -p ${train_dir}/model ${train_dir}/sgf

if [[ ! -z ${link_sgf} ]]; then
ln ${link_sgf}/* ${train_dir}/sgf/
end_iteration=$(ls ${train_dir}/sgf/ | wc -l)
echo "link ${link_sgf} ..."
echo "end_iteration: ${end_iteration}"
fi

touch ${train_dir}/op.log
new_configure_file=$(basename ${train_dir}).cfg

${sp_executable_file} -gen ${train_dir}/${new_configure_file} -conf_file ${configure_file} -conf_str "${overwrite_conf_str}" 2>/dev/null

# Add a setting only when the generated cfg does not already have it.
# The old unconditional append duplicated these three CornPuzzle keys.
append_cornpuzzle_cfg "${train_dir}/${new_configure_file}" "${configure_file}"

# setup initial weight
cuda_devices=$(echo ${gpu_list} | awk '{ split($0, chars, ""); printf(chars[1]); for(i=2; i<=length(chars); ++i) { printf(","chars[i]); } }')
echo "train \"\" -1 -1" | CUDA_VISIBLE_DEVICES=${cuda_devices} PYTHONPATH=. python ${op_executable_file} ${game_type} ${train_dir} ${train_dir}/${new_configure_file} >/dev/null 2>&1

elif [[ ${run_stage,} == "c" ]]; then
zero_start_iteration=$(ls ${train_dir}/model/ | grep ".pt$" | wc -l)
model_file=$(ls ${train_dir}/model/ | grep ".pt$" | sort -V | tail -n1)
new_configure_file=$(basename ${train_dir}/*.cfg)

echo y | ${sp_executable_file} -gen ${train_dir}/${new_configure_file} -conf_file ${train_dir}/${new_configure_file} -conf_str "${overwrite_conf_str}" 2>/dev/null

# Add CornPuzzle folder-puzzle settings into generated training cfg.
append_cornpuzzle_cfg "${train_dir}/${new_configure_file}" "${configure_file}"

# friendly notification if continuing training
if [[ -n ${MINIZERO_CONFIRM_CONTINUE:-} ]]; then
yn=${MINIZERO_CONFIRM_CONTINUE}
echo "Continue training from iteration: ${zero_start_iteration}, model file: ${model_file}, configuration: ${train_dir}/${new_configure_file}. Automatic confirmation: ${yn}"
else
read -n1 -p "Continue training from iteration: ${zero_start_iteration}, model file: ${model_file}, configuration: ${train_dir}/${new_configure_file}. Sure? (y/n) " yn
fi
[[ ${yn,,} == "y" ]] || exit
echo ""
else
exit
fi

# run zero server
conf_str="zero_training_directory=${train_dir}:zero_end_iteration=${end_iteration}:nn_file_name=${model_file}:zero_start_iteration=${zero_start_iteration}"

if [[ ! -z ${link_sgf} ]]; then
conf_str="$conf_str:zero_num_games_per_iteration=0"
fi

${sp_executable_file} -conf_file ${train_dir}/${new_configure_file} -conf_str ${conf_str} -mode zero_server


